//package com.example.login_page1;
//import android.content.Context;
//import android.content.Intent;
//public class Extensions {
//        public static void nextPg(Context context, Class<?> nextPage) {
//            Intent intent = new Intent(context, nextPage);
//            context.startActivity(intent);
//        }
//
//
//
//}
